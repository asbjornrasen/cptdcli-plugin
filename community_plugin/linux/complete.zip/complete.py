# complete.py — CPTD CLI Command


from cptd_tools.os_guard import ensure_compatible
ensure_compatible(__file__)

from pathlib import Path
import argparse
import pkgutil
import cptd_tools.commands
from cptd_tools.syntax_utils import print_help

SYNTAX = {
    "name": "complete",
    "description": "Autocomplete CPTD commands by prefix.",
    "usage": "cptd complete --prefix <text>",
    "arguments": [
        {
            "name": "--prefix",
            "required": False,
            "help": "Prefix to match command names"
        }
    ],
    "examples": [
        "cptd complete --prefix rep",
        "cptd complete --prefix dash"
    ]
}

def list_commands():
    commands_dir = Path(__file__).resolve().parents[1]
    if not commands_dir.name == "commands":
        return []

    return [
        f.name for f in commands_dir.iterdir()
        if f.is_dir() and not f.name.startswith("__")
    ]




def run(argv):
    if "--help" in argv or "-h" in argv:
        print_help(SYNTAX)
        return

    parser = argparse.ArgumentParser(description=SYNTAX["description"], add_help=False)
    parser.add_argument('--prefix', type=str, required=False, help='Prefix to match command names')

    try:
        args = parser.parse_args(argv)
    except Exception as e:
        print(f"[!] Argument error: {e}")
        print_help(SYNTAX)
        return

    all_cmds = list_commands()
    if args.prefix:
        matches = [cmd for cmd in all_cmds if cmd.startswith(args.prefix)]
    else:
        matches = all_cmds

    print('\n'.join(matches))

