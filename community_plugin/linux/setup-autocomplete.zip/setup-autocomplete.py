from cptd_tools.os_guard import ensure_compatible
ensure_compatible(__file__)

import os
from pathlib import Path
from cptd_tools.syntax_utils import print_help

SYNTAX = {
    "name": "setup-autocomplete",
    "description": "Install Bash auto-completion for cptd CLI commands by prefix",
    "usage": "cptd setup-autocomplete",
    "arguments": [],
    "examples": ["cptd setup-autocomplete"]
}

COMPLETION_SCRIPT = """
_cptd_complete() {
    local cur
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    if [[ ${COMP_CWORD} -eq 1 ]]; then
        local cmds=$(cptd complete --prefix "$cur" 2>/dev/null)
        COMPREPLY=( $(compgen -W "${cmds}" -- "${cur}") )
    fi
}
complete -F _cptd_complete cptd
"""

def run(argv):
    if "--help" in argv or "-h" in argv:
        print_help(SYNTAX)
        return

    target_file = Path.home() / ".cptd-completion.sh"
    bashrc_file = Path.home() / ".bashrc"

    # Шаг 1: записать скрипт автодополнения
    with open(target_file, "w") as f:
        f.write(COMPLETION_SCRIPT.strip() + "\n")
    print(f"✅ Completion script written to {target_file}")

    # Шаг 2: добавить source в .bashrc, если его нет
    line_to_add = f"source {target_file}"
    bashrc_contents = bashrc_file.read_text() if bashrc_file.exists() else ""
    if line_to_add not in bashrc_contents:
        with open(bashrc_file, "a") as f:
            f.write(f"\n# Enable CPTD CLI autocomplete\n{line_to_add}\n")
        print(f"✅ Line added to {bashrc_file}")
    else:
        print(f"ℹ️ .bashrc already includes completion script")

    print("🔄 Please run: source ~/.bashrc")
    print("✅ Done. Now try typing: cptd com<Tab>")
