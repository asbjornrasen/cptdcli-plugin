from pathlib import Path
import subprocess
import argparse
import platform
from cptd_tools.syntax_utils import print_help
import logging
from datetime import datetime

# Определяем каталог logs (например, рядом с исполняемым скриптом)
ROOT = Path(__file__).parent
LOGS_DIR = ROOT / "logs"
LOGS_DIR.mkdir(exist_ok=True)

# Формируем имя файла: logs/YYYY-MM-DD_taskname.log
task_name = "reminder"
log_file = LOGS_DIR / f"{datetime.now().strftime('%Y-%m-%d')}_{task_name}.log"

# Настройка логгера
logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    encoding="utf-8"
)    



SYNTAX = {
    "name": "pshellwrap",
    "description": "Runs a specified PowerShell script with arguments via CPTD CLI on Windows",
    "usage": "cptd pshellwrap --script <path> [--args \"...\"]",
    "arguments": [
        {"name": "--script", "required": True, "help": "Path to PowerShell script"},
        {"name": "--args", "required": False, "help": "Additional arguments for the script"}
    ],
    "examples": [
        "cptd pshellwrap --script C:/scripts/myscript.ps1 --args \"-Param1 foo -Param2 bar\""
    ]
}

def run(argv):
    if "--help" in argv or "-h" in argv:
        print_help(SYNTAX)
        return

    # Check if running on Windows
    if platform.system() != "Windows":
        print("[!] This command is designed to run on Windows only.")
        return

    parser = argparse.ArgumentParser()
    parser.add_argument("--script", type=str, required=True, help="Path to PowerShell script")
    parser.add_argument("--args", type=str, default="", help="Additional arguments for the script")

    try:
        args = parser.parse_args(argv)
    except Exception as e:
        print(f"[!] Argument error: {e}")
        print_help(SYNTAX)
        return

    script_path = Path(args.script)
    if not script_path.exists():
        print(f"[!] Script not found: {script_path}")
        return

    # Build PowerShell command with ExecutionPolicy bypass
    cmd = f'powershell.exe -ExecutionPolicy Bypass -File "{script_path}" {args.args}'

    print(f"[✔] Running: {cmd}")
    logging.info("[OK] running") # запись в файл    
    subprocess.run(cmd, shell=True)
