#!/usr/bin/env python3
# CPTD command: portwho

import argparse, json, os, subprocess, psutil
from cptd_tools.syntax_utils import print_help
from datetime import datetime

SYNTAX = {
    "name": "portwho",
    "description": "Анализ: кто использует порт (только Windows)",
    "usage": "cptd portwho [--port 1462] [--ports 135 445] [--json openports.json] [--output result.txt|result.json]",
    "arguments": [
        {"name": "--port", "required": False, "help": "Один порт"},
        {"name": "--ports", "required": False, "help": "Список портов через пробел"},
        {"name": "--json", "required": False, "help": "JSON-файл с open_ports"},
        {"name": "--output", "required": False, "help": "Файл для вывода результатов (.txt или .json)"}
    ],
    "examples": [
        "cptd portwho --port 1462",
        "cptd portwho --ports 135 445 5040",
        "cptd portwho --json localhost.json",
        "cptd portwho --port 135 --output result.txt"
    ]
}

def print_service_by_pid(pid):
    try:
        cmd = f'tasklist /svc /FI "PID eq {pid}"'
        result = subprocess.check_output(cmd, shell=True, encoding="cp866", stderr=subprocess.DEVNULL)
        lines = result.strip().split('\n')
        return lines[2] if len(lines) >= 3 else "Н/Д"
    except Exception:
        return "Н/Д"


def analyze_port(port, output_list):
    found = False
    for conn in psutil.net_connections(kind='inet'):
        if conn.laddr and conn.status == 'LISTEN' and conn.laddr.port == port:
            pid = conn.pid
            proc_name = "System (PID 4)" if pid == 4 or pid is None else psutil.Process(pid).name()
            raw_info = print_service_by_pid(pid) if pid else "Н/Д"
            parts = raw_info.split()
            service_image = parts[0] if parts else "Н/Д"
            service_name = " ".join(parts[1:]) if len(parts) > 1 else "Н/Д"

            result = {
                "port": port,
                "protocol": "TCP",
                "process": proc_name,
                "pid": pid,
                "services": service_image,
                "name": service_name,
                "ip_address": conn.laddr.ip
            }
            output_list.append(result)

            print(f"\nПорт        : {port}")
            print(f"Протокол    : TCP")
            print(f"Процесс     : {proc_name} (PID {pid})")
            print(f"Службы      : {service_image} — {service_name}")
            print(f"IP-адрес    : {conn.laddr.ip}")
            print("----------------------------")
            found = True
    if not found:
        print(f"[!] Порт {port} не слушается.")
        output_list.append({"port": port, "error": "Порт не слушается"})
def get_ports_from_json(path):
    try:
        with open(path, 'r', encoding="utf-8") as f:
            return json.load(f).get("open_ports", [])
    except Exception as e:
        print(f"[!] Ошибка чтения JSON: {e}")
        return []

def save_output(results, output_path):
    try:
        if output_path.endswith(".json"):
            with open(output_path, 'w', encoding="utf-8") as f:
                json.dump(results, f, ensure_ascii=False, indent=2)
            print(f"[✔] Результат сохранён в {output_path}")
        elif output_path.endswith(".txt"):
            with open(output_path, 'w', encoding="utf-8") as f:
                for r in results:
                    if "error" in r:
                        f.write(f"Порт {r['port']}: {r['error']}\n")
                    else:
                        f.write(
                            f"Порт: {r['port']} | Протокол: {r['protocol']} | Процесс: {r['process']} (PID {r['pid']}) | "
                            f"Службы: {r['services']} | IP: {r['ip_address']}\n"
                        )
            print(f"[✔] Результат сохранён в {output_path}")
        else:
            print(f"[!] Неподдерживаемый формат: {output_path}")
    except Exception as e:
        print(f"[!] Ошибка сохранения: {e}")

def run(argv):
    if "--help" in argv or "-h" in argv:
        print_help(SYNTAX)
        return

    parser = argparse.ArgumentParser(prog="cptd portwho")
    parser.add_argument('--port', type=int)
    parser.add_argument('--ports', nargs='+', type=int)
    parser.add_argument('--json', type=str)
    parser.add_argument('--output', type=str)

    try:
        args = parser.parse_args(argv)
    except Exception as e:
        print(f"[!] Argument error: {e}")
        print_help(SYNTAX)
        return

    ports = []
    if args.ports:
        ports = args.ports
        print(f"[+] Используются явно указанные порты: {ports}")
    elif args.port:
        ports = [args.port]
        print(f"[+] Используется один порт: {args.port}")
    elif args.json and os.path.exists(args.json):
        ports = get_ports_from_json(args.json)
        print(f"[+] Порты загружены из JSON: {ports}")
    else:
        print("[!] Не указаны порты и не найден JSON.")
        print_help(SYNTAX)
        return

    results = []
    print("\n🔍 Анализ портов:")
    for port in ports:
        analyze_port(port, results)

    if args.output:
        save_output(results, args.output)
