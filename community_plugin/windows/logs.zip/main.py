from pathlib import Path
import argparse, site, sysconfig, sys
import logging
from datetime import datetime

# ────────── локальный лог самой команды (необязательно) ──────────
ROOT = Path(__file__).parent
LOCAL_LOGS = ROOT / "logs"
LOCAL_LOGS.mkdir(exist_ok=True)
log_file = LOCAL_LOGS / f"{datetime.now():%Y-%m-%d}_logs_cmd.log"
logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    encoding="utf-8"
)

# ───────────────── SYNTAX (требование CPTD) ─────────────────
SYNTAX = {
    "name": "logs",
    "description": "Чтение и удаление лог-файлов задач CPTD",
    "usage": "cptd logs [--read | --delete] <taskname>",
    "arguments": [
        {"name": "--read",   "help": "Показать логи (по умолчанию)"},
        {"name": "--delete", "help": "Удалить логи"},
        {"name": "taskname", "required": True, "help": "Имя задачи / команды"}
    ],
    "examples": [
        "cptd logs echo_console",
        "cptd logs --delete echo_console"
    ]
}

# ─────────── helpers ───────────
def _command_logs_dir(taskname: str) -> Path:
    """Возвращает путь <site-packages>/cptd_tools/commands/<task>/logs."""
    bases = (
        [Path(p) for p in site.getsitepackages()] +
        [Path(site.getusersitepackages())] +
        [Path(sysconfig.get_path("purelib"))]
    )

    seen, uniq = set(), []
    for p in bases:
        if p not in seen:
            uniq.append(p)
            seen.add(p)

    for base in uniq:
        cand = base / "cptd_tools" / "commands" / taskname / "logs"
        if cand.exists():
            return cand

    return uniq[0] / "cptd_tools" / "commands" / taskname / "logs"


def _logs_read(taskname: str) -> None:
    logs_dir = _command_logs_dir(taskname)
    if not logs_dir.exists():
        print(f"[ℹ] Папка logs не найдена:\n    {logs_dir}")
        return
    files = sorted(logs_dir.glob("*.log"))
    if not files:
        print(f"[ℹ] В папке {logs_dir} нет *.log файлов.")
        return
    for f in files:
        print(f"\n📄 {f.name}\n" + "-" * 60)
        print(f.read_text(encoding="utf-8"))


def _logs_delete(taskname: str) -> None:
    logs_dir = _command_logs_dir(taskname)
    if not logs_dir.exists():
        print(f"[ℹ] Папка logs не найдена:\n    {logs_dir}")
        return
    files = list(logs_dir.glob("*.log"))
    if not files:
        print(f"[ℹ] В папке {logs_dir} нет *.log файлов.")
        return
    for f in files:
        try:
            f.unlink()
            print(f"[✔] Удалён: {f.name}")
        except Exception as e:
            print(f"[!] Не удалось удалить {f.name}: {e}")

# ─────────── run() — точка входа ───────────
def run(argv):
    if {"-h", "--help"}.intersection(argv):
        _print_help()
        return

    prs = argparse.ArgumentParser(add_help=False)
    grp = prs.add_mutually_exclusive_group(required=False)
    grp.add_argument("--read",   action="store_true")
    grp.add_argument("--delete", action="store_true", dest="delete")
    prs.add_argument("taskname")
    args = prs.parse_args(argv)

    # действие по умолчанию — read
    if not args.read and not args.delete:
        args.read = True

    if args.read:
        _logs_read(args.taskname)
    else:
        _logs_delete(args.taskname)

    logging.info("[OK] Команда logs завершена")

# ─────────── help ───────────
def _print_help():
    print(f"{SYNTAX['usage']}\n\n{SYNTAX['description']}\n")
    print("Аргументы / опции:")
    for a in SYNTAX["arguments"]:
        req = " (обяз.)" if a.get("required") else ""
        print(f"  {a['name']:<10} — {a['help']}{req}")
    print("\nПримеры:")
    for ex in SYNTAX["examples"]:
        print(f"  {ex}")

# ─────────── для лок. отладки ───────────
if __name__ == "__main__":
    run(sys.argv[1:])
