import socket
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from cptd_tools.syntax_utils import print_help

SYNTAX = {
    "name": "portscanner",
    "description": "Multithreaded TCP Port Scanner in Python with Timeouts",
    "usage": "cptd portscanner --ip <IP> --start <port> --end <port> [--timeout <ms>] [--threads <N>]",
    "arguments": [
        {"name": "--ip", "required": True, "help": "Target IP address"},
        {"name": "--start", "required": True, "help": "Starting port"},
        {"name": "--end", "required": True, "help": "End port"},
        {"name": "--timeout", "required": False, "help": "Connection timeout in ms (default 300)"},
        {"name": "--threads", "required": False, "help": "Parallel threads (default 100)"},
        {"name": "--output", "required": False, "help": "Saving the result to a file"},
        {"name": "--output-format", "required": False, "help": "Output format: text or json (default text)"}
    ],
    "examples": [
        "cptd portscanner --ip 192.168.1.1 --start 20 --end 80",
        "cptd portscanner --ip scanme.nmap.org --start 1 --end 1024 --timeout 500 --threads 200",
        "cptd portscanner --ip 192.168.1.1 --start 1 --end 1024 --output result.txt --output-format text",
        "cptd portscanner --ip 192.168.1.1 --start 1 --end 1024 --output result.json --output-format json"
    ]
}


def scan_port(ip: str, port: int, timeout_ms: int) -> int | None:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout_ms / 1000.0)
            s.connect((ip, port))
            return port
    except:
        return None


def run(argv):
    if "--help" in argv or "-h" in argv:
        print_help(SYNTAX)
        return

    parser = argparse.ArgumentParser()
    parser.add_argument("--ip", required=True)
    parser.add_argument("--start", type=int, required=True)
    parser.add_argument("--end", type=int, required=True)
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--threads", type=int, default=100)
    parser.add_argument("--output", type=str, default=None)
    parser.add_argument("--output-format", choices=["text", "json"], default="text")
    

    try:
        args = parser.parse_args(argv)
    except Exception as e:
        print(f"[!] Argument error: {e}")
        print_help(SYNTAX)
        return

    print(f"[•] Port scanning {args.start}-{args.end} на {args.ip}...")

    open_ports = []
    with ThreadPoolExecutor(max_workers=args.threads) as executor:
        future_to_port = {
            executor.submit(scan_port, args.ip, port, args.timeout): port
            for port in range(args.start, args.end + 1)
        }

        for future in as_completed(future_to_port):
            port = future_to_port[future]
            try:
                result = future.result()
                if result:
                    open_ports.append(result)
            except Exception:
                pass

    
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            if args.output_format == "json":
                import json
                json.dump({
                    "host": args.ip,
                    "start_port": args.start,
                    "end_port": args.end,
                    "timeout_ms": args.timeout,
                    "threads": args.threads,
                    "open_ports": sorted(open_ports)
                }, f, ensure_ascii=False, indent=2)
            else:
                f.write(f"host: {args.ip}\n")
                f.write(f"start_port: {args.start}\n")
                f.write(f"end_port: {args.end}\n")
                f.write(f"timeout_ms: {args.timeout}\n")
                f.write(f"threads: {args.threads}\n")
                f.write(f"open_ports: {len(open_ports)}\n")
                for p in sorted(open_ports):
                    f.write(f"port: {p}\n")


    if open_ports:
        open_ports.sort()
        print(f"\n[✔] Open ports found: {len(open_ports)}")
        for p in open_ports:
            print(f"[+] The port is open: {p}")
    else:
        print("\n[•] No open ports found.")
