# scheduler_daemon.py
# ------------------------------------------------------------
# CPTD Scheduler — multithreaded daemon + autostart GUI agent
# ------------------------------------------------------------
import os, platform, socket, subprocess, sys, time, json, traceback, yaml, shlex, psutil
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from pathlib import Path

# ────── PATH ──────
scripts_dir = Path(sys.executable).parent / "Scripts"
os.environ["PATH"] = f"{scripts_dir};" + os.environ.get("PATH", "")

# ────── директории / файлы ──────
ROOT        = Path(__file__).parent.resolve()
STATE_FILE  = ROOT / "scheduler_state.json"
LOG_PATH    = ROOT / "scheduler.log"
PID_PATH    = ROOT / "daemon.pid"
GUI_QUEUE   = ROOT / "gui_queue.txt"

# name → pid
RUNNING_PIDS = {}

def _get_schedule_dir() -> Path:
    if STATE_FILE.exists():
        try:
            cfg = json.loads(STATE_FILE.read_text())
            if cfg.get("config_path"):
                return Path(cfg["config_path"])
        except Exception:
            pass
    return ROOT / "schedules"

SCHEDULES_DIR = _get_schedule_dir()
SCHEDULES_DIR.mkdir(parents=True, exist_ok=True)

# ────── logging (thread safe) ──────
log_lock = threading.Lock()
def log(msg: str):
    with log_lock, LOG_PATH.open("a", encoding="utf-8") as f:
        f.write(f"[{datetime.now().isoformat(timespec='seconds')}] {msg}\n")





# ────── Thread-pool ──────
max_workers = int(os.getenv("CPTD_SCHED_MAX_THREADS", 16))
executor     = ThreadPoolExecutor(max_workers=max_workers)
state_lock   = threading.Lock()         # защита task_state
task_state   = {}                       # {name: last_run_datetime}

log(f"[ℹ] Thread pool: {max_workers} workers")

# ────── auxiliary functions ──────
parse_time  = lambda t: datetime.strptime(t, "%H:%M").time()
parse_date  = lambda d: datetime.strptime(d, "%Y-%m-%d").date()
check_file  = lambda p: Path(p).exists()
def check_net(host): 
    try: socket.create_connection((host, 80), 2); return True
    except: return False

# ────── launch one task ──────
def _task_runner(name, cmd, retries, require_gui, console, allow_duplicates):
    # ── house‑keeping: drop stale PIDs so the table never grows indefinitely
    for t_name, t_pid in list(RUNNING_PIDS.items()):
        if t_pid != -1 and not psutil.pid_exists(t_pid):
            RUNNING_PIDS.pop(t_name, None)

    for attempt in range(1, retries + 2):
        try:
            # ── duplicate guard ────────────────────────────────────────────────
            if not allow_duplicates:
                # 1) in‑memory fast‑path
                pid = RUNNING_PIDS.get(name)
                if pid and pid != -1 and psutil.pid_exists(pid):
                    log(f"[⏩] Skipping '{name}' — already running (PID {pid})")
                    return

                # 2) for GUI tasks we look for an existing window / process
                if require_gui:
                    for p in psutil.process_iter(["pid", "cmdline", "name"]):
                        try:
                            cmdline = " ".join(p.info["cmdline"]).lower()
                            if cmd.split()[0].lower() in cmdline:
                                RUNNING_PIDS[name] = p.pid
                                log(f"[⏩] Detected running GUI instance of '{name}' (PID {p.pid})")
                                return
                        except Exception:
                            pass

            # ── really launch ─────────────────────────────────────────────────
            log(f"[→] Running task '{name}' (attempt {attempt}) — {cmd}")

            if require_gui:
                with GUI_QUEUE.open("a", encoding="utf-8") as q:
                    q.write(f"{datetime.now().isoformat()}|{name}|{cmd}|{int(console)}\n")
                if not allow_duplicates:
                    # mark as *queued*; will be replaced by real PID by the
                    # duplicate‑removal block once the app appears in the
                    # process list (next iterations)
                    RUNNING_PIDS[name] = -1
                log(f"[→] GUI task queued: {name}")
            else:
                proc = subprocess.Popen(
                    cmd,
                    shell=True,
                    creationflags=subprocess.CREATE_NO_WINDOW | 0x00000008,  # DETACHED_PROCESS
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                if not allow_duplicates:
                    RUNNING_PIDS[name] = proc.pid
                log(f"[✔] Task launched (async): {name} — PID {proc.pid}")

            with state_lock:
                task_state[name] = datetime.now()
            return

        except Exception as e:
            log(f"[!] Task error {name}: {e}")
            log(traceback.format_exc())
            time.sleep(5)



def run_command(name, cmd, retries, require_gui, console=True, allow_duplicates=False):
    executor.submit(_task_runner, name, cmd, retries, require_gui, console, allow_duplicates)


# ────── Launch GUI agent ──────
def launch_gui_agent():
    pyw = Path(sys.executable).with_name("pythonw.exe")
    exe = pyw if pyw.exists() else sys.executable
    flags = subprocess.CREATE_NO_WINDOW | 0x00000008
    try:
        subprocess.Popen([exe, str(ROOT / "gui_agent.py")],
                         creationflags=flags,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        log("[✔] GUI Agent launched.")
    except Exception as e:
        log(f"[!] GUI Agent launch failed: {e}")


# ────── main loop ──────
def main():
    log("Scheduler daemon started.")
    PID_PATH.write_text(str(os.getpid()))

  

    while True:
        try:
        
            for fpath in SCHEDULES_DIR.glob("*.y*ml"):
                cfg = yaml.safe_load(fpath.read_text("utf-8")) or {}
                if not cfg.get("enabled", True):
                    continue

                name   = cfg["name"]
                cmd    = cfg.get("command")
                dsl    = cfg.get("cpdsl")
                sched  = cfg["schedule"]
                cond   = cfg.get("conditions", {})
                retry  = int(cond.get("retry", 0))
                need_gui   = bool(cond.get("require_gui"))
                if cond.get("if_file_exists")   and not check_file(cond["if_file_exists"]): continue
                if cond.get("only_on_network")  and not check_net(cond["only_on_network"]): continue

                exec_cmd = f'cptd cpdsl run {dsl}' if dsl else cmd
                if not exec_cmd: continue

                with state_lock:
                    last_run = task_state.get(name, datetime.min)
                now = datetime.now()

                typ = sched.get("type")
                eligible = False

                if typ == "interval":
                    if now - last_run >= timedelta(minutes=int(sched.get("interval", 15))):
                        eligible = True
                elif typ == "daily":
                    dt = datetime.combine(now.date(), parse_time(sched["time"]))
                    if last_run < dt <= now < dt + timedelta(minutes=1): eligible = True
                elif typ == "hourly":
                    if now.minute == int(sched.get("minute", 0)) and now - last_run >= timedelta(hours=1):
                        eligible = True
                elif typ == "weekly":
                    daymap = {"MON":0,"TUE":1,"WED":2,"THU":3,"FRI":4,"SAT":5,"SUN":6}
                    if daymap.get(sched["day"][:3].upper()) == now.weekday():
                        dt = datetime.combine(now.date(), parse_time(sched["time"]))
                        if last_run < dt <= now < dt + timedelta(minutes=1): eligible = True
                elif typ == "once":
                    dt = datetime.combine(parse_date(sched["date"]), parse_time(sched["time"]))
                    if last_run < dt <= now < dt + timedelta(minutes=1): eligible = True
                elif typ == "periodic":
                    base = datetime.combine(now.date(), parse_time(sched["start"]))
                    inter = int(sched["interval"])
                    if base <= now and (now - base).total_seconds() % (inter*60) < 60:
                        if now - last_run >= timedelta(minutes=inter): eligible = True

                if eligible:
                    console_flag = bool(cond.get("console", True))
                    allow_dups = bool(cond.get("allow_duplicates", False))
                    run_command(name, exec_cmd, retry, need_gui, console_flag, allow_dups)

            time.sleep(30)

        except Exception as e:
            log(f"[CRASH] {e}")
            log(traceback.format_exc())
            time.sleep(10)

# ────── entry ──────
if __name__ == "__main__":
    if platform.system() != "Windows":
        log("[!] Windows-only build"); sys.exit(1)
    # launch_gui_agent()
    # GUI-the agent is needed only in console (--start/--auto-on) mode.
    is_service = "--service" in sys.argv
    if not is_service:
        launch_gui_agent()
    main()
