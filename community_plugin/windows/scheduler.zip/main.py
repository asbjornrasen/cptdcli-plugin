#scheduler main.py for windows 
import argparse
import subprocess
import sys
import os
import json
import platform
from pathlib import Path
import shutil 
import yaml
from cptd_tools.syntax_utils import print_help

SYNTAX = {
  "name": "cptd scheduler",
  "description": "Manage CPTD Scheduler tasks and services",
  "usage": "cptd scheduler [--start] [--stop] [--reload] [--status] [--sysservice-on] [--sysservice-off] [--auto-on] [--auto-off] [--config-path <path>] [--yaml]",
  "arguments": [
    {"name": "--help", "required": False, "help": "Show help"},
    {"name": "--start", "required": False, "help": "Start the daemon"},
    {"name": "--stop", "required": False, "help": "Stop the daemon"},
    {"name": "--reload", "required": False, "help": "Reload the daemon"},
    {"name": "--status", "required": False, "help": "Daemon status"},
    {"name": "--auto-on", "required": False, "help": "Create a Startup shortcut"},
    {"name": "--auto-on-advanced", "required": False, "help": "Task scheduler instead of shortcut"},
    {"name": "--auto-off", "required": False, "help": "Remove the autostart"},
    {"name": "--unregister", "required": False, "help": "Alias for --auto-off"},
    {"name": "--sysservice-on", "required": False, "help": "Install as a system service"},
    {"name": "--sysservice-off", "required": False, "help": "Remove the system service"},
    {"name": "--config-path", "required": False, "help": "Directory with .yaml schedules"},
    {"name": "--lock-path", "required": False, "help": "Show current schedule directory"},
    {"name": "--reset-path", "required": False, "help": "Reset the schedule directory path to default"},
    {"name": "--yaml", "required": False, "help": "Generate a YAML template for a task"},
    {"name": "--list-yaml", "required": False, "help": "List all YAML files in the schedule directory"},
    {"name": "--add-yaml", "required": False, "help": "Add a YAML file to the schedule directory"},
    {"name": "--del-yaml", "required": False, "help": "Delete a YAML file from the schedule directory"},
    {"name": "--status-service", "required": False, "help": "Check the status of the CPTD_Scheduler service"},
    {"name": "--start-service", "required": False, "help": "Start the stopped CPTD_Scheduler service"},
    {"name": "--reload-service", "required": False, "help": "Reload the CPTD_Scheduler system service"},
    {"name": "--stop-service", "required": False, "help": "Stop the CPTD_Scheduler system service"},
    {"name": "--logs-read", "required": False, "help": "Show the scheduler.log"},
    {"name": "--logs-delete", "required": False, "help": "Delete the scheduler.log"},
    {"name": "--list", "required": False, "help": "List available schedule YAML files"}
  ],
  "examples": [
    "cptd scheduler --start",
    "cptd scheduler --stop",
    "cptd scheduler --status",
    "cptd scheduler --add-yaml /path/to/task.yaml",
    "cptd scheduler --list-yaml"
  ]
}


scripts_dir = Path(sys.executable).parent / "Scripts"
os.environ["PATH"] = f"{scripts_dir};" + os.environ["PATH"]

STATE_FILE = Path(__file__).parent / "scheduler_state.json"
PID_FILE   = Path(__file__).parent / "daemon.pid"
ROOT      = Path(__file__).parent
LOG_PATH  = ROOT / "scheduler.log"        

def _kill_gui_agent():
    agent_pid_file = Path(__file__).parent / "gui_agent.pid"
    try:
        if agent_pid_file.exists():
            pid = int(agent_pid_file.read_text())
            import psutil
            if psutil.pid_exists(pid):
                p = psutil.Process(pid)
                p.terminate()
                p.wait(timeout=5)
                print(f"[✔] GUI-agent (PID {pid}) stopped.")
            else:
                print("[ℹ] PID GUI-agent does not exist.")
            agent_pid_file.unlink(missing_ok=True)
        else:
            print("[ℹ] PID-файл GUI-agent not found.")
    except Exception as e:
        print(f"[!] Failed to stop GUI-agent: {e}")


def _create_startup_shortcut(name: str, target_script: Path, delay_cmd: bool=False):
    try:
        import win32com.client

        startup = (Path(os.environ["APPDATA"]) /
                   "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup")
        startup.mkdir(parents=True, exist_ok=True)

        lnk_path = startup / f"{name}.lnk"

        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortcut(str(lnk_path))
        pythonw = Path(sys.executable).with_name("pythonw.exe")
        if delay_cmd:
            # cmd /c timeout 15 & pythonw gui_agent.py
            pythonw = Path(sys.executable).with_name("pythonw.exe")
            exe = pythonw if pythonw.exists() else sys.executable
            shortcut.TargetPath = str(Path(sys.executable).with_name("cmd.exe"))
            shortcut.Arguments  = f'/c timeout 15 & "{exe}" "{target_script}"'

        else:
            shortcut.TargetPath = str(pythonw if pythonw.exists() else sys.executable)
            shortcut.Arguments  = f'"{target_script}"'

        shortcut.WorkingDirectory = str(Path(sys.executable).parent)
        shortcut.WindowStyle = 7  
        shortcut.Description = "CPTD Scheduler daemon autostart"
        shortcut.Save()

        print(f"[✔] Shortcut created: {lnk_path}")

    except ImportError:
        print("[!] pywin32 is not installed. Install it: pip install pywin32")
    except Exception as e:
        print(f"[!] Failed to create shortcut: {e}")




# ───────────────────────── helpers ─────────────────────────
def save_config_path(path: str):
    STATE_FILE.write_text(json.dumps({"config_path": path}))

def load_config_path() -> str | None:
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text()).get("config_path")
        except Exception:
            return None
    return None

def add_yaml_file(file_path: Path):
    """Add the specified YAML file to the schedule directory."""
    schedule_dir = get_schedule_dir()
    if not schedule_dir.exists():
        print(f"[!] Directory does not exist: {schedule_dir}")
        return

    if not file_path.exists():
        print(f"[!] The specified file does not exist: {file_path}")
        return

    # Copy the file to the schedules directory
    try:
        shutil.copy(file_path, schedule_dir)
        print(f"[✔] File '{file_path.name}' added to the schedule directory.")
    except Exception as e:
        print(f"[!] Error copying file: {e}")

def del_yaml_file(file_name: str):
    """Delete the specified YAML file from the schedule directory."""
    schedule_dir = get_schedule_dir()
    if not schedule_dir.exists():
        print(f"[!] Directory does not exist: {schedule_dir}")
        return

    file_path = schedule_dir / file_name
    if not file_path.exists():
        print(f"[!] The specified file does not exist: {file_path}")
        return

    try:
        file_path.unlink()
        print(f"[✔] File '{file_name}' has been deleted from the schedule directory.")
    except Exception as e:
        print(f"[!] Error deleting file: {e}")

def get_schedule_dir() -> Path:
    custom = load_config_path()
    return Path(custom) if custom else Path(__file__).parent / "schedules"

def get_daemon_path() -> str:
    return str(Path(__file__).parent / "scheduler_daemon.py")

def list_yaml_files(schedule_dir: Path):
    """List all YAML files in the schedule directory."""
    if not schedule_dir.exists():
        print(f"[!] Directory does not exist: {schedule_dir}")
        return

    yaml_files = list(schedule_dir.glob("*.yaml")) + list(schedule_dir.glob("*.yml"))
    if not yaml_files:
        print(f"[!] No YAML files found in {schedule_dir}")
        return

    print(f"YAML files in {schedule_dir}:")
    for f in yaml_files:
        print(f"📄 {f.name}")


# ─────────────────────── autorun (Windows) ─────────────────
def _install_user_autorun(advanced: bool = False):

    if platform.system() != "Windows":
        print("[!] User-level autorun is implemented only for Windows.")
        return

    if advanced:
        pythonw = Path(sys.executable).with_name("pythonw.exe")
        exe     = pythonw if pythonw.exists() else Path(sys.executable)
        cmd     = (
            'schtasks /create /tn "CPTD_Scheduler" /sc onlogon '
            f'/tr "{exe} \\"{get_daemon_path()}\\"" /ru SYSTEM /rl HIGHEST /f'
        )
        res = subprocess.run(cmd, shell=True)
        print("[✔] The task has been created in the Scheduler." if res.returncode == 0
              else "[!] Failed to create task (run as administrator).")
    else:
        _create_startup_shortcut("CPTD_Scheduler", Path(get_daemon_path()))
        _create_startup_shortcut("CPTD_GUI_Agent",
                                 Path(__file__).parent / "gui_agent.py",
                                 delay_cmd=True)
        print("[✔] User-level autorun created (daemon + GUI agent).")



def _uninstall_user_autorun():
    if platform.system() != "Windows":
        return

    subprocess.run('schtasks /delete /tn "CPTD_Scheduler" /f',
                   shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    startup = (Path(os.environ["APPDATA"]) /
               "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup")

    (startup / "CPTD_Scheduler.lnk").unlink(missing_ok=True)
    (startup / "CPTD_GUI_Agent.lnk").unlink(missing_ok=True)
    subprocess.run('schtasks /delete /tn "CPTD_GUI_Agent" /f',
               shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    print("[✔] User-autostart removed (labels + schtasks task).")





def find_nssm() -> str | None:
    local = Path(__file__).parent / "nssm.exe"
    if local.exists():
        return str(local)
    return shutil.which("nssm")


def _install_system_service():
    if platform.system() != "Windows":
        print("[!] Services are supported on Windows only.")
        return

    nssm = find_nssm()
    if not nssm:
        print("[!] NSSM not found. Install nssm.exe and add to %PATH%, or put it nearby.")
        return

    python_path = sys.executable
    script_path = get_daemon_path()
    svc_name    = "CPTD_Scheduler"

    subprocess.run(f'{nssm} remove {svc_name} confirm', shell=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    # we pass a flag so that the daemon understands that it is running from Service-0
    subprocess.run(f'{nssm} install {svc_name} "{python_path}" "{script_path}" --service', shell=True)
    subprocess.run(f'{nssm} set {svc_name} AppDirectory "{Path(script_path).parent.resolve()}"', shell=True)
    subprocess.run(f'{nssm} set {svc_name} DisplayName "CPTD Scheduler daemon"', shell=True)
    subprocess.run(f'{nssm} set {svc_name} Start SERVICE_AUTO_START', shell=True)
    subprocess.run(f'{nssm} start {svc_name}', shell=True)
    _register_gui_agent()
    print(f"[✔] Service {svc_name} is installed and started via NSSM.")

def _register_gui_agent():

    agent_path = Path(__file__).parent / "gui_agent.py"
    if not agent_path.exists():
        print("[!] gui_agent.py not found. Skipping GUI agent registration.")
        return

    # take pythonw.exe if it exists
    pythonw = Path(sys.executable).with_name("pythonw.exe")
    exe = pythonw if pythonw.exists() else Path(sys.executable)

    # escaped string for schtasks: "C:\Python\pythonw.exe" "...\gui_agent.py"
    cmd = (
        'schtasks /create /tn "CPTD_GUI_Agent" /sc onlogon '
        f'/tr "\"{exe}\" \"{agent_path}\"" /rl LIMITED /f'
    )

    res = subprocess.run(cmd, shell=True)
    if res.returncode == 0:
        print("[✔] GUI-agent is registered in the Task Scheduler.")
        subprocess.run('schtasks /run /tn "CPTD_GUI_Agent"', shell=True)
    else:
        print("[!] Error registering GUI agent.")



def _unregister_gui_agent():
    subprocess.run('schtasks /delete /tn "CPTD_GUI_Agent" /f',
                   shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print("[✔] GUI-agent has been removed from the Task Scheduler.")



def _remove_system_service():
    if platform.system() != "Windows":
        return
    nssm = find_nssm()
    if not nssm:
        print("[!] NSSM not found. Unable to remove service.")
        return
    svc_name = "CPTD_Scheduler"
    subprocess.run(f'"{nssm}" stop {svc_name}', shell=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run(f'"{nssm}" remove {svc_name} confirm', shell=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    _unregister_gui_agent()
    print("[✔] The CPTD_Scheduler service has been removed.")


# ───────────────────────── process utils ───────────────────
def _kill_scheduler():
    try:
        import psutil
        for p in psutil.process_iter(["pid", "cmdline"]):
            if p.info["cmdline"] and "scheduler_daemon.py" in " ".join(p.info["cmdline"]):
                p.kill()
    except Exception as e:
        print(f"[!] Failed to stop the daemon: {e}")



# ───────────────────────── process utils ─────────────────
def _logs_read():
    if LOG_PATH.exists():
        print(f"\n📄 scheduler.log\n" + "-" * 60)
        print(LOG_PATH.read_text(encoding="utf-8"))
    else:
        print("[ℹ] The scheduler.log file has not yet been created.")


def _logs_delete():
    if LOG_PATH.exists():
        try:
            LOG_PATH.unlink()
            print("[✔] Removed: scheduler.log")
        except Exception as e:
            print(f"[!] Failed to delete scheduler.log: {e}")
    else:
        print("[ℹ] File scheduler.log not found.")


def generate_yaml_template():
    # Define the template structure
    template = {
        "name": "Task Name",
        "description": "Short description of the task",
        "enabled": True,  # Indicates whether the task is active
        "command": "your_command_here",  # The command to execute
        "cpdsl": "cpdsl_command.dsl",  # The .cpdsl script file to execute

        "schedule": {
            "type": "interval",  # Possible values: "interval", "daily", "hourly", "weekly", "once", "periodic"
            "interval": 15,  # Time in minutes (for "interval" type)
            "time": "12:00",  # Time of day (HH:mm format) for "daily" and "once" types
            "day": "MON",  # Day of the week for "weekly" type
            "date": "2025-08-03",  # Date for "once" type
            "start": "08:00",  # Start time for "periodic" type
            "retry": 3,  # Number of retries in case of failure
        },

        "conditions": {
            "require_gui": True,  # Whether the task requires a GUI
            "if_file_exists": "/path/to/file",  # Condition for the existence of a file
            "only_on_network": "example.com",  # Condition for network availability
            "console": True,  # Whether the task should run in the console
            "allow_duplicates": False,  # Prevent task execution if it's already running
        },

        "run_as_admin": False,  # Whether to run the task with administrator privileges
    }

    # Save to YAML file
    output_path = "task_template.yaml"
    with open(output_path, "w") as file:
        yaml.dump(template, file, default_flow_style=False,  sort_keys=False)

    print(f"YAML template created at: {os.path.abspath(output_path)}")

# Helper function to get the schedule directory
def get_schedule_dir() -> Path:
    custom = load_config_path()
    return Path(custom) if custom else Path(__file__).parent / "schedules"

def load_config_path() -> str | None:
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text()).get("config_path")
        except Exception:
            return None
    return None

# ────────────────────────────── CLI ────────────────────────
def run(argv):
    prs = argparse.ArgumentParser("cptd scheduler (Windows-only build)", add_help=False)


    prs.add_argument("--helpt", action="store_true", help="Show help")
    prs.add_argument("--start",  action="store_true", help="Start the daemon")
    prs.add_argument("--stop",   action="store_true", help="Stop the demon")
    prs.add_argument("--reload", action="store_true", help="Restart the daemon")
    prs.add_argument("--status", action="store_true", help="Demon status")

    prs.add_argument("--auto-on",            action="store_true", help="Create a shortcut in Startup")
    prs.add_argument("--auto-on-advanced",   action="store_true", help="Task scheduler instead of a shortcut")
    prs.add_argument("--auto-off",           action="store_true", help="Remove autostart")
    prs.add_argument("--unregister",         action="store_true", help="Synonym --auto-off")

    prs.add_argument("--sysservice-on",  action="store_true", help="Install as system service")
    prs.add_argument("--sysservice-off", action="store_true", help="Remove system service")

    prs.add_argument("--config-path", type=str, help="Directory с .yaml schedules")
    prs.add_argument("--lock-path",   action="store_true", help="Show current schedule directory")
    prs.add_argument("--reset-path",  action="store_true", help="Reset schedule path to default")
    prs.add_argument("--yaml", action="store_true", help="Generate a YAML template for a task")
    prs.add_argument("--list-yaml", action="store_true", help="List all YAML files in the schedule directory")
    prs.add_argument("--add-yaml", type=Path, help="Add a YAML file to the schedule directory")
    prs.add_argument("--del-yaml", type=str, help="Delete a YAML file from the schedule directory")

    prs.add_argument("--status-service", action="store_true", help="Check the status of the CPTD_Scheduler service")
    prs.add_argument("--start-service",  action="store_true", help="Start stopped CPTD_Scheduler service")
    prs.add_argument("--reload-service", action="store_true", help="Restart the CPTD_Scheduler system service")
    prs.add_argument("--stop-service", action="store_true", help="Stop the CPTD_Scheduler system service")
    prs.add_argument("--logs-read", action="store_true", help="Show scheduler.log")
    prs.add_argument("--logs-delete",  action="store_true", help="Delete scheduler.log")
    prs.add_argument("--list", action="store_true", help="List available schedule YAML files")



    args = prs.parse_args(argv)

    daemon = get_daemon_path()

    if "--help" in argv or "-h" in argv:
        print_help(SYNTAX)
        return
    
    # Add YAML file to the directory
    if args.add_yaml:
        add_yaml_file(args.add_yaml)
        return

    # Delete YAML file from the directory
    if args.del_yaml:
        del_yaml_file(args.del_yaml)
        return

    if args.list_yaml:
        schedule_dir = get_schedule_dir()
        list_yaml_files(schedule_dir)
        return

    if args.yaml:
        generate_yaml_template()  # <-- Generate the YAML template
        return

    if args.reset_path:
        # delete the file with the custom path, if there was one
        if STATE_FILE.exists():
            STATE_FILE.unlink(missing_ok=True)
        print("[✔] The path to the schedules has been reset: "
              f"{Path(__file__).parent / 'schedules'}")
        return

    # Manage path to configs
    if args.config_path:
        save_config_path(args.config_path)
        print(f"[✔] The path to the schedules is saved: {args.config_path}")
        return
    if args.lock_path:
        print(f"[ℹ] Schedule dir: {get_schedule_dir()}")
        return
    
    if args.list:
            schedule_dir = get_schedule_dir()
            if not schedule_dir.exists():
                print(f"[!] No schedules directory found at {schedule_dir}")
                return
            files = list(schedule_dir.glob("*.yaml")) + list(schedule_dir.glob("*.yml"))
            if not files:
                print(f"[!] No YAML schedule files found in {schedule_dir}")
                return
            for f in files:
                try:
                    import yaml
                    data = yaml.safe_load(f.read_text(encoding="utf-8"))
                    name = data.get("name", f.name)
                    description = data.get("description", "No description")
                    print(f"\n📄 {name} — {description}")

                    # General task parameters
                    if "command" in data:
                        print(f"   command:        {data['command']}")
                    if "schedule" in data:
                        print(f"   schedule:")
                        for k, v in data["schedule"].items():
                            print(f"      {k}: {v}")
                    if "conditions" in data:
                        print(f"   conditions:")
                        for k, v in data["conditions"].items():
                            print(f"      {k}: {v}")
                    if "run_as_admin" in data:
                        print(f"   run_as_admin:   {data['run_as_admin']}")
                    if data.get("cpdsl"):
                        print(f"   cpdsl:")
                        for i, cmd in enumerate(data["cpdsl"], 1):
                            print(f"      - {cmd}")

                    # Steps
                    steps = data.get("steps", [])
                    if steps:
                        print("   steps:")
                        for i, step in enumerate(steps, 1):
                            print(f"    ── Step {i}")
                            print(f"       name:        {step.get('name', 'N/A')}")
                            print(f"       command:     {step.get('command', 'N/A')}")
                            args_dict = step.get('args', {})
                            if args_dict:
                                print(f"       args:")
                                for k, v in args_dict.items():
                                    print(f"          {k}: {v}")
                            if step.get('async'):
                                print(f"       async:       true")
                            if step.get('depends_on'):
                                print(f"       depends_on:  {step.get('depends_on')}")
                            print("")
                    else:
                        print("   [ℹ] No steps section defined.")
                except Exception as e:
                    print(f"[!] Failed to load {f.name}: {e}")
            return


    # user-level автозапуск
    if args.auto_off or args.unregister:
        _uninstall_user_autorun()
        print("[✔] User-autostart removed.")
        return

    if args.auto_on or args.auto_on_advanced:
        _install_user_autorun(advanced=args.auto_on_advanced)
        return

    # system service
    if args.sysservice_on:
        _install_system_service()
        return
    if args.sysservice_off:
        _remove_system_service()
        return

    if args.start:
        DETACHED_PROCESS = 0x00000008
        CREATE_NO_WINDOW = subprocess.CREATE_NO_WINDOW
        flags = DETACHED_PROCESS | CREATE_NO_WINDOW



        p = subprocess.Popen(
            [sys.executable, daemon],
            creationflags=flags,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        
        # launch the GUI agent
        pythonw = Path(sys.executable).with_name("pythonw.exe")
        exe_gui = pythonw if pythonw.exists() else sys.executable

        # in parallel we start the GUI agent
        subprocess.Popen(
            [exe_gui, Path(__file__).parent / "gui_agent.py"],
            creationflags=flags,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        PID_FILE.write_text(str(p.pid))
        print(f"[✔] The daemon is running with PID {p.pid}.")
        return



    if args.stop:
        _kill_scheduler()
        _kill_gui_agent()
        PID_FILE.unlink(missing_ok=True)
        print("[✔] The demon has been stopped.")
        return

    if args.reload:
        _kill_scheduler()
        subprocess.Popen([sys.executable, daemon],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("[✔] The demon has been restarted.")
        return



    if args.status:
        try:
            import psutil
            running = PID_FILE.exists() and psutil.pid_exists(int(PID_FILE.read_text()))
            print("[✔] Launched" if running else "[ ] Not running")
        except ImportError:
            if PID_FILE.exists():
                try:
                    pid = int(PID_FILE.read_text())
                    res = subprocess.run(f'tasklist /FI "PID eq {pid}"', shell=True,
                                        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
                    if str(pid) in res.stdout:
                        print("[✔] Launched (по tasklist)")
                    else:
                        print("[ ] Not running")
                except Exception:
                    print("[ ] Status unknown (tasklist error)")
            else:
                print("[ ] Not running (no PID file)")
        return

    
    if args.status_service:
        try:
            result = subprocess.run(
                'sc query CPTD_Scheduler', shell=True,
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True
            )
            if "RUNNING" in result.stdout:
                print("[✔] The CPTD_Scheduler service is running.")
            elif "STOPPED" in result.stdout:
                print("[ ] The CPTD_Scheduler service is installed but stopped.")
            else:
                print("[ ] The CPTD_Scheduler service is not installed.")
        except Exception:
            print("[!] Failed to check service status.")
        return
    

    if args.start_service:
        nssm = find_nssm()
        if not nssm:
            print("[!] NSSM not found. Service cannot start.")
            return
        svc_name = "CPTD_Scheduler"
        start_res = subprocess.run(f'"{nssm}" start {svc_name}', shell=True)
        if start_res.returncode == 0:
            print("[✔] The CPTD_Scheduler service is running.")
        else:
            print("[!] The service could not be started (it may already be running).")
        return
    
    if args.reload_service:
        nssm = find_nssm()
        if not nssm:
            print("[!] NSSM not found. Service cannot be restarted.")
            return
        svc_name = "CPTD_Scheduler"
        stop_res = subprocess.run(f'"{nssm}" stop {svc_name}', shell=True)
        if stop_res.returncode != 0:
            print("[!] Failed to stop the service.")
            return
        start_res = subprocess.run(f'"{nssm}" start {svc_name}', shell=True)
        if start_res.returncode != 0:
            print("[!] Failed to start the service.")
            return
        print("[✔] The CPTD_Scheduler service has been restarted (stop/start).")
        return
    
    if args.stop_service:
        nssm = find_nssm()
        if not nssm:
            print("[!] NSSM not found. Unable to stop service.")
            return
        svc_name = "CPTD_Scheduler"
        stop_res = subprocess.run(f'"{nssm}" stop {svc_name}', shell=True)
        if stop_res.returncode != 0:
            print("[!] Failed to stop the service.")
        else:
            print("[✔] The CPTD_Scheduler service has stopped.")
        return
    
    if args.logs_read:
        _logs_read()
        return

    if args.logs_delete:
        _logs_delete()
        return



  
    print_help(SYNTAX)

if __name__ == "__main__":
    run(sys.argv[1:])
