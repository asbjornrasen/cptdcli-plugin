# gui_agent.py
# ---------------------------------------------
# GUI queue handler: shows windows without
# black console, multithreaded via ThreadPool
# ---------------------------------------------
import os, sys, time, psutil, subprocess, threading, traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

from pathlib import Path

ROOT  = Path(__file__).parent.resolve()
QUEUE = ROOT / "gui_queue.txt"
LOCK  = ROOT / "gui_queue.lock"
LOG   = ROOT / "agent.log"
PID   = ROOT / "gui_agent.pid"

CREATE_NO_WINDOW = subprocess.CREATE_NO_WINDOW


# ────── log ──────
log_lock = threading.Lock()
def log(msg: str):
    with log_lock, LOG.open("a", encoding="utf-8") as f:
        f.write(f"[{datetime.now().isoformat(timespec='seconds')}] {msg}\n")

# ────── PID-protection ──────
def is_running():
    if PID.exists():
        try:
            pid = int(PID.read_text())
            if psutil.pid_exists(pid):
                return True
            PID.unlink(missing_ok=True)
        except Exception:
            PID.unlink(missing_ok=True)
    return False

def write_pid(): PID.write_text(str(os.getpid()))

# ────── thread pool ──────
max_workers = int(os.getenv("CPTD_GUI_MAX_THREADS", 16))
executor = ThreadPoolExecutor(max_workers=max_workers)
log(f"[ℹ] Thread pool: {max_workers} workers")

# ────── task ──────
def _launch_gui(cmd: str, name: str, use_console: bool):
    try:
        flags = DETACHED if use_console else CREATE_NO_WINDOW
        stdout = subprocess.DEVNULL
        stderr = subprocess.DEVNULL

        if cmd.lower().endswith('.exe') or cmd.lower().startswith('cptd '):
            subprocess.Popen(
                cmd,
                shell=True,
                creationflags=flags,
                stdout=stdout,
                stderr=stderr
            )
        else:
            subprocess.Popen(
                f'cmd /c {cmd}',
                shell=True,
                creationflags=flags,
                stdout=stdout,
                stderr=stderr
            )
        log(f"[✔] Launched GUI: {name}")
    except Exception as e:
        log(f"[!] GUI task error {name}: {e}")
        log(traceback.format_exc())
        # return the string to the queue with the use_console flag
        with QUEUE.open("a", encoding="utf-8") as q:
            q.write(f"{datetime.now().isoformat()}|{name}|{cmd}|{int(use_console)}\n")




def process_queue():
    if not QUEUE.exists(): return

    lines = [l for l in QUEUE.read_text("utf-8").splitlines() if l]
    if not lines: return
    QUEUE.write_text("", encoding="utf-8")   # очищаем сразу
    futures = []

    for line in lines:
        try:
            parts = line.strip().split("|")
            if len(parts) == 4:
                ts, name, cmd, console_flag = parts
                use_console = console_flag.strip() == "1"
            else:
                ts, name, cmd = parts
                use_console = True
            futures.append(executor.submit(_launch_gui, cmd, name, use_console))
        except Exception as e:
            log(f"[!] Malformed line: {line} — {e}")

    for f in as_completed(futures):
        pass    # we are waiting for exceptions to appear in the log


DETACHED = 0x00000008   # we leave it, but we don't need GUI control anymore

def main():
    if is_running():
        log("[!] GUI-agent already running"); return
    write_pid()
    log("[✔] GUI-agent started")

    while True:
        try:
            process_queue()
            time.sleep(5)
        except Exception as e:
            log(f"[CRASH] {e}")
            log(traceback.format_exc())
            time.sleep(5)

if __name__ == "__main__":
    main()
