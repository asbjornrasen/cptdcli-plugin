### Complete List of YAML Fields for CPTD Scheduler

> Below is a list of **all** keys that `scheduler_daemon.py` actually parses during each scan of the `schedules/` directory. For clarity, they are grouped into top-level fields, the `schedule` block, and the `conditions` block.

---

#### 1. Top-Level Fields

| Field          | Type          | Required | Default / Example | Description                                                                                       |
| -------------- | ------------- | -------- | ----------------- | ------------------------------------------------------------------------------------------------- |
| `name`         | string        | ✅        | —                 | Unique task name. Used for state tracking and to prevent duplicate runs.                          |
| `description`  | string        | —        | —                 | Human-readable comment. Shown in `cptd scheduler --list`.                                         |
| `enabled`      | bool          | —        | `true`            | Temporarily disable the task without deleting the file.                                           |
| `command`      | string        | ⬜        | —                 | Shell command to execute (can be GUI or console-based).                                           |
| `cpdsl`        | string / list | ⬜        | —                 | Path(s) to `.dsl` script(s) instead of `command`. Scheduler auto-expands to `cptd cpdsl run ...`. |
| `run_as_admin` | bool          | —        | `false`           | Reserved for future admin-elevation support (currently used only in `--list`).                    |
| `schedule`     | object        | ✅        | —                 | Time/frequency configuration block (see below).                                                   |
| `conditions`   | object        | —        | `{}`              | Additional launch conditions (see below).                                                         |

---

#### 2. `schedule` Block

| Field              | Subfields                                 | Purpose                                                                                               |
| ------------------ | ----------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `type`             | —                                         | Specifies schedule type. Allowed values: `interval`, `daily`, `hourly`, `weekly`, `once`, `periodic`. |
| **For `interval`** | `interval` (int, in minutes, default: 15) | Run every *N* minutes.                                                                                |
| **For `daily`**    | `time` (`HH:MM`)                          | Run once per day at given time.                                                                       |
| **For `hourly`**   | `minute` (0-59, default: 0)               | Run every hour when system time reaches the specified minute.                                         |
| **For `weekly`**   | `day` (`MON`–`SUN`), `time` (`HH:MM`)     | Run once a week on the given weekday and time.                                                        |
| **For `once`**     | `date` (`YYYY-MM-DD`), `time`             | Run once at the exact datetime.                                                                       |
| **For `periodic`** | `start` (`HH:MM`), `interval` (minutes)   | Repeating cycle from `start` every `interval` minutes (within same day).                              |

> **All times are interpreted in local system time.**

---

#### 3. `conditions` Block

| Field              | Type          | Default | Meaning                                                                            |
| ------------------ | ------------- | ------- | ---------------------------------------------------------------------------------- |
| `retry`            | int           | `0`     | Number of retries on failure (non-zero exit code).                                 |
| `require_gui`      | bool          | `false` | Queue this task for `gui_agent` (no black console window).                         |
| `if_file_exists`   | string (path) | —       | Run only if the given file or folder exists.                                       |
| `only_on_network`  | string (host) | —       | Run only if the given host is reachable via TCP on port 80.                        |
| `console`          | bool          | `true`  | If `false`, GUI tasks will be launched without visible terminal window.            |
| `allow_duplicates` | bool          | `false` | Allow multiple simultaneous instances. If false, task won’t run if already active. |

---

#### 4. Minimal Example

```yaml
name:  "Backup DB"
description: "Daily DB export and cloud copy"
enabled: true

command: "your_command"
# or "scripts/backup.dsl"

schedule:
  type: daily
  time: "03:30"

conditions:
  retry: 2
  only_on_network: "intranet.local"
  allow_duplicates: false
```

#### 5. Example
---
```yaml
name: "Task Name"
description: "Short description of the task"
enabled: true  # Indicates whether the issue is active.

schedule:
  type: "interval"  # Possible values: "interval", "daily", "hourly", "weekly", "once", "periodic"
  interval: 15  # Time in minutes (for type "interval")
  time: "12:00"  # Time of day (HH:mm format) for "daily" and "once" types
  day: "MON"  # Day of the week for the "weekly" type
  date: "2025-08-03"  # Date for type "once"
  start: "08:00"  # Start time for type "periodic"
  retry: 3  # Number of attempts on failure

conditions:
  require_gui: true  # Does the task require a GUI?
  if_file_exists: "/path/to/file"  # Condition for file existence
  only_on_network: "example.com"  # Network condition
  console: true  # The task must be executed in the console
  allow_duplicates: false  # Execution of task is prohibited if it is already running

command: "your_command_here"  # Command to be executed
cpdsl: "cpdsl_command.dsl"
  
run_as_admin: true  # Whether to run the task with administrator rights

```

##### Helpful CLI Commands

```bash
cptd scheduler --list        # List all YAML tasks with descriptions
cptd scheduler --reload      # Reload the scheduler after changes
cptd scheduler --lock-path   # Show current schedules directory
```

You now have a complete reference for writing CPTD scheduler YAML files — ready to define, customize, and automate your tasks with precision.
